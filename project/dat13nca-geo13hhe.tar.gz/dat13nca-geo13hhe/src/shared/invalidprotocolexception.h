#ifndef INVALID_PROTOCOL_EXCEPTION_H
#define INVALID_PROTOCOL_EXCEPTION_H

struct InvalidProtocolException {
};

#endif
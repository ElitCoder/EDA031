#ifndef INPUT_H
#define INPUT_H

#include <string>

namespace Input {
    std::string getString();
    int getInt();    
}

#endif
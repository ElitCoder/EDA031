#ifndef SERVER_ERROR_EXCEPTION_H
#define SERVER_ERROR_EXCEPTION_H

struct ServerErrorException {
};

#endif